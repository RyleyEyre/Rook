import { lazy } from 'react'

export const LoginPage = lazy(() => import('./pages/LoginPage/index.js'))
